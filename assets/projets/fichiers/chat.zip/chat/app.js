const express = require('express')
const app = express()
const fs = require('fs')
const mysql = require('mysql')
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'QE20170421_ec19',
    database: 'chats'
})
connection.connect()

let messages = []

connection.query('SELECT * FROM messages', (err, res) => {
    if (err)
        console.error(err)
    
    res.forEach(element => {
        messages.push({ 'id': element.id, 'pseudo': element.pseudo, 'message': element.message })
    });
})

app.get('/', (req, res) => {
    fs.readFile('index.html', 'utf-8', (err, data) => {
        if (err)
            console.error(err)

        res.setHeader('Content-Type', 'text/html')
        res.end(data)
    })
})

app.get('/messages', (req, res) => {
    res.json(messages)
})

app.use(express.static('css'))

const server = app.listen(8080)

const io = require('socket.io').listen(server)

io.sockets.on('connection', socket => {
    //On prend le pseudo de l'utilisateur
    socket.on('pseudo', pseudo => {
        socket.pseudo = pseudo
    })

    //On affiche le message chez l'utilisateur + les autres utilisateurs
    socket.on('message', message => {
        const data = {
            'message': message,
            'pseudo': socket.pseudo
        }
        connection.query('INSERT INTO messages(pseudo, message) VALUES ("' + data.pseudo + '", "' + data.message + '")', (err, res) => {
            if (err)
                console.error(err)
        })
        socket.emit('nouveau_message', data)
        socket.broadcast.emit('nouveau_message_autre', data)
    })
})
